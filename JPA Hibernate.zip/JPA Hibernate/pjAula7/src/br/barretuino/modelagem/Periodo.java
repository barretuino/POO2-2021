package br.barretuino.modelagem;

public enum Periodo {
	DIARIO, SEMANAL, MENSAL, BIMESTRAL, TRIMESTRAL, SEMESTRAL, ANUAL;
}
